package com.learning.spring.social.bindings;

import lombok.Data;

@Data
public class AddCommentForm {
    private String content;
}
